import React from 'react';
import style from './RestorePass.module.css';

// type RestorePassPropsType = any

// const RestorePass = (props: RestorePassPropsType) => {
// 	return (
// 		<div className={style.restorePass}>
// 			<h2>Restore password page</h2>
// 		</div>
// 	)
// }

// export default RestorePass;